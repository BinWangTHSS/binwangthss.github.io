Figure 1: Room scene.
Figure 2: Bulb scene.
Figure 4: Torus scene scene.
Figure 6: Killeroos scene.
Figure 7: Villa housescene.
Figure 8: Cornell box scene.